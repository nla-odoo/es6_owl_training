# -*- coding: utf-8 -*-

{
    'name': 'Test Widget',
    'summary': 'Widget field',
    'version': '1.0',
    'data': [
        # 'security/ir.model.access.csv',
        # 'views/widget_view.xml',
    ],
    'installable': True,
    'application': True,
}